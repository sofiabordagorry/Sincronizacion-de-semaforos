package org.uma.jmetal.algorithm.multiobjective.mombi.util;

public class R2SolutionData {
	public int rank = Integer.MAX_VALUE;
	public double utility = Double.POSITIVE_INFINITY;
	public double alpha = 0.0;
}