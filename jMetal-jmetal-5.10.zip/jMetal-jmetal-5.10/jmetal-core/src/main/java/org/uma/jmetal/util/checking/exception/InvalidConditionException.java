package org.uma.jmetal.util.checking.exception;

@SuppressWarnings("serial")
public class InvalidConditionException extends RuntimeException {
  public InvalidConditionException(String message) {
    super(message) ;
  }
}
